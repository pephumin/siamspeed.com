<?php
/*
	Package manifest file for Add Social Media Icons To Profiles

	Author - hcfwesker (http://www.simplemachines.org/community/index.php?action=profile;u=244295)
	License - http://creativecommons.org/licenses/by-sa/3.0/ CC BY-SA 3.0
	
	Version - 1.2.0
*/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	$ssi = true;
	require_once(dirname(__FILE__) . '/SSI.php');
}
elseif (!defined('SMF'))
	exit('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

global $smcFunc;

if(!array_key_exists('db_add_column', $smcFunc))
	db_extend('packages');

$column_array = array(
	'column1' => array(
		'name' => 'facebook', 
		'type' => 'varchar',
		'size' => '45',
		'null' => false,
		'default' => '',
	),
	'column2' => array(
		'name' => 'myspace', 
		'type' => 'varchar',
		'size' => '45',
		'null' => false,
		'default' => '',
	),
	'column3' => array(
		'name' => 'twitter', 
		'type' => 'varchar',
		'size' => '45',
		'null' => false,
		'default' => '',
	),
	'column4' => array(
		'name' => 'youtube', 
		'type' => 'varchar',
		'size' => '45',
		'null' => false,
		'default' => '',
	),
	'column5' => array(
		'name' => 'deviantart', 
		'type' => 'varchar',
		'size' => '45',
		'null' => false,
		'default' => ''
	),
	'column6' => array(
		'name' => 'googleplus', 
		'type' => 'varchar',
		'size' => '45',
		'null' => false,
		'default' => ''
	),
	'column7' => array(
		'name' => 'linkedin', 
		'type' => 'varchar',
		'size' => '65',
		'null' => false,
		'default' => ''
	),
	'column8' => array(
		'name' => 'pinterest', 
		'type' => 'varchar',
		'size' => '45',
		'null' => false,
		'default' => ''
	),
);

foreach ($column_array as $key => $data)
{
	$smcFunc['db_add_column'](
		'{db_prefix}members',
		$data,
		array(),
		'update',
		'fatal'
	);
}

global $smcFunc;

if(!array_key_exists('db_add_column', $smcFunc))
	db_extend('packages');

$column_array = array(
	'column1' => array(
		'name' => 'customsmiicon', 
		'type' => 'varchar',
		'size' => '45',
		'null' => false,
		'default' => '',
	),
);

foreach ($column_array as $key => $data)
{
	$smcFunc['db_add_column'](
		'{db_prefix}custom_fields',
		$data,
		array(),
		'update',
		'fatal'
	);
}

?>