This modification allows the categories, boards and topics of your choices to be removed from the recent post lists.

Just go to
Administration Center � Modification Settings � Recent Posts Setting 
and put the ids of categories, boards and topics you want to remove from recent posts list.

For example if you want to remove category 1 and 2 from the list, just put the category ids like

1,2 (just have a comma in between and don't leave any space).

Same goes for boards and topics also.


Update - 
1. You can also hide the topics by clicking "Hide" button within the topics. One can unhide/undo the topic using the same button.
2. You can set permission for each member group who can access the hide button in topics. To adjust the permission go to permission section in admin panel and set the permission for each group separately.


- Note: This mod only hides the items in the recent post listing that is shown on the board index.